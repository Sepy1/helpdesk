<!doctype html>
<html lang="id" class="h-full bg-gray-50">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>@yield('title','Helpdesk')</title>
  @vite(['resources/css/app.css','resources/js/app.js'])
  {{-- Alpine --}}
  <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="h-full font-sans antialiased" x-data="{ sidebarOpen: true, mobileOpen: false }">

  <!-- Topbar -->
  <header class="bg-white border-b sticky top-0 z-40">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
      <div class="flex items-center gap-3">
        {{-- Toggle untuk desktop & mobile --}}
        <button
          class="inline-flex md:hidden items-center justify-center h-9 w-9 rounded-lg hover:bg-gray-100 text-gray-600"
          @click="mobileOpen = true" aria-label="Buka menu">
          ☰
        </button>
        <button
          class="hidden md:inline-flex items-center justify-center h-9 w-9 rounded-lg hover:bg-gray-100 text-gray-600"
          @click="sidebarOpen = !sidebarOpen" aria-label="Tampilkan/sembunyikan menu">
          ☰
        </button>

        <div class="h-9 w-9 rounded-xl bg-indigo-600/10 flex items-center justify-center">
          <span class="text-indigo-600 font-bold">HD</span>
        </div>
        <span class="font-semibold text-gray-800">Helpdesk</span>
      </div>

      <nav class="flex items-center gap-4 text-sm">
        @auth
          <span class="hidden sm:inline text-gray-500">
            {{ auth()->user()->name }} — <span class="uppercase">{{ auth()->user()->role }}</span>
          </span>
          <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button class="inline-flex items-center px-3 py-1.5 rounded-lg bg-gray-900 text-white hover:bg-gray-800">
              Logout
            </button>
          </form>
        @endauth
      </nav>
    </div>
  </header>

  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex gap-6 py-6">
      {{-- Sidebar (desktop) --}}
      <aside
        class="hidden md:block shrink-0 transition-all duration-200"
        :class="sidebarOpen ? 'w-64' : 'w-0'"
        aria-label="Sidebar">
        <div class="h-[calc(100vh-112px)] sticky top-[88px] overflow-y-auto border-r bg-white"
             :class="sidebarOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'">
          @include('layouts.partials.sidebar')
        </div>
      </aside>

      {{-- Konten --}}
      <main class="flex-1 min-w-0">
        @if(session('success'))
          <div class="mb-4 rounded-lg bg-green-50 text-green-700 px-4 py-3 border border-green-200">
            {{ session('success') }}
          </div>
        @endif
        @if(session('error'))
          <div class="mb-4 rounded-lg bg-red-50 text-red-700 px-4 py-3 border border-red-200">
            {{ session('error') }}
          </div>
        @endif

        @yield('content')
      </main>
    </div>
  </div>

  {{-- Drawer Mobile --}}
  <div x-show="mobileOpen" x-cloak class="fixed inset-0 z-50 md:hidden">
    <div class="absolute inset-0 bg-black/40" @click="mobileOpen=false"></div>
    <div class="absolute left-0 top-0 bottom-0 w-72 bg-white p-4 shadow-xl">
      <div class="mb-4 flex justify-between items-center">
        <div class="font-semibold text-gray-800">Menu</div>
        <button class="h-8 w-8 inline-flex items-center justify-center rounded-md hover:bg-gray-100"
                @click="mobileOpen=false">✕</button>
      </div>
      @include('layouts.partials.sidebar')
    </div>
  </div>
</body>
</html>
