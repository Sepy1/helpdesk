@php
  $isIT     = auth()->user()->role === 'IT';
  $isCabang = auth()->user()->role === 'CABANG';
@endphp

<div class="p-4">
  <div class="text-xs font-semibold text-gray-500 mb-2">MENU</div>

  @if($isIT)
    <a href="{{ route('it.dashboard') }}"
       class="flex items-center gap-3 px-3 py-2 rounded-lg mb-1
              {{ request()->routeIs('it.dashboard') ? 'bg-gray-900 text-white' : 'text-gray-700 hover:bg-gray-100' }}">
      <span>📊</span> <span>Daftar Tiket</span>
    </a>
    <a href="{{ route('it.my') }}"
     class="flex items-center gap-3 px-3 py-2 rounded-lg mb-1
            {{ request()->routeIs('it.my') ? 'bg-gray-900 text-white' : 'text-gray-700 hover:bg-gray-100' }}">
    <span>🧑‍💻</span> <span>Tiket Saya</span>
     {{-- badge jumlah ON_PROGRESS milik saya --}}
    @php
      $myCount = \App\Models\Ticket::where('it_id', auth()->id())
                  ->where('status', 'ON_PROGRESS')->count();
    @endphp
    <span class="ml-auto text-xs rounded-full px-2 py-0.5 bg-amber-100 text-amber-800">{{ $myCount }}</span>
  </a>

  <a href="{{ route('it.stats') }}"
     class="flex items-center gap-3 px-3 py-2 rounded-lg mb-1
            {{ request()->routeIs('it.stats') ? 'bg-gray-900 text-white' : 'text-gray-700 hover:bg-gray-100' }}">
    <span>📈</span> <span>Statistik</span>
  </a>
  </a>



  @endif

  @if($isCabang)
    <a href="{{ route('cabang.dashboard') }}"
       class="flex items-center gap-3 px-3 py-2 rounded-lg mb-1
              {{ request()->routeIs('cabang.dashboard') ? 'bg-gray-900 text-white' : 'text-gray-700 hover:bg-gray-100' }}">
      <span>➕</span> <span>Buat Tiket</span>
    </a>
    <a href="{{ route('cabang.tickets') }}"
       class="flex items-center gap-3 px-3 py-2 rounded-lg mb-1
              {{ request()->routeIs('cabang.tickets') ? 'bg-gray-900 text-white' : 'text-gray-700 hover:bg-gray-100' }}">
      <span>🗂️</span> <span>Tiket Saya</span>
       {{-- badge jumlah tiket saya yang ON_PROGRESS --}}
    @php
      $myCabOnProgress = \App\Models\Ticket::where('user_id', auth()->id())
                          ->where('status', 'ON_PROGRESS')
                          ->count();
    @endphp
    <span class="ml-auto text-xs rounded-full px-2 py-0.5 bg-amber-100 text-amber-800">
      {{ $myCabOnProgress }}
    </span> 
    </a>


  @endif

  
  
</div>
