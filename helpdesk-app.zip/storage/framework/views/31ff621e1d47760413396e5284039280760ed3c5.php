
<?php $__env->startSection('title','Tiket Saya (Diambil)'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-2xl shadow-sm ring-1 ring-gray-100 p-6">
  <div class="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between mb-4">
    <div>
      <h2 class="text-lg font-semibold text-gray-800">Tiket Saya (Sedang Ditangani)</h2>
      <p class="text-sm text-gray-500">Daftar tiket dengan handler: <?php echo e(auth()->user()->name); ?></p>
    </div>

    
    <form method="GET" action="<?php echo e(route('it.my')); ?>" class="grid grid-cols-2 sm:flex gap-2">
      <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari nomor / deskripsi"
             class="rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
      <select name="kategori" class="rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
        <option value="">Kategori</option>
        <?php $__currentLoopData = ['JARINGAN','LAYANAN','CBS','OTHER']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($k); ?>" <?php if(request('kategori')===$k): echo 'selected'; endif; ?>><?php echo e($k); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <select name="status" class="rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
        <option value="">Status</option>
        <?php $__currentLoopData = ['OPEN','ON_PROGRESS','CLOSED']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($s); ?>" <?php if(request('status')===$s): echo 'selected'; endif; ?>><?php echo e($s); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <button class="rounded-lg bg-gray-900 text-white px-3 py-2">Filter</button>
    </form>
  </div>

  <div class="overflow-x-auto">
    <table class="min-w-full text-sm">
      <thead class="text-left bg-gray-50 text-gray-600">
        <tr>
          <th class="py-3 px-4">#</th>
          <th class="py-3 px-4">Nomor</th>
          <th class="py-3 px-4">Kategori</th>
          <th class="py-3 px-4">Pembuat</th>
          <th class="py-3 px-4">Status</th>
          <th class="py-3 px-4">Aksi</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-gray-100">
        <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr class="hover:bg-gray-50">
            <td class="py-3 px-4 text-gray-500"><?php echo e($tickets->firstItem() + $i); ?></td>
            <td class="py-3 px-4 font-medium">
              <a class="text-indigo-600 hover:underline" href="<?php echo e(route('ticket.show', $t->id)); ?>">
                <?php echo e($t->nomor_tiket); ?>

              </a>
            </td>
            <td class="py-3 px-4"><?php echo e($t->kategori); ?></td>
            <td class="py-3 px-4"><?php echo e($t->user->name ?? '-'); ?></td>
            <td class="py-3 px-4">
              <?php
                $badge = match($t->status) {
                  'OPEN' => 'bg-gray-100 text-gray-700 ring-gray-200',
                  'ON_PROGRESS' => 'bg-amber-100 text-amber-800 ring-amber-200',
                  'CLOSED' => 'bg-emerald-100 text-emerald-800 ring-emerald-200',
                };
              ?>
              <span class="inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ring-1 <?php echo e($badge); ?>">
                <?php echo e($t->status); ?>

              </span>
            </td>
            <td class="py-3 px-4">
              
              <?php if($t->status === 'ON_PROGRESS'): ?>
                <form class="inline" method="POST" action="<?php echo e(route('it.ticket.release',$t->id)); ?>">
                  <?php echo csrf_field(); ?>
                  <button class="rounded-lg bg-gray-200 px-3 py-1.5 text-gray-700 hover:bg-gray-300">Lepas</button>
                </form>
                <form class="inline" method="POST" action="<?php echo e(route('it.ticket.close',$t->id)); ?>">
                  <?php echo csrf_field(); ?>
                  <button class="rounded-lg bg-emerald-600 px-3 py-1.5 text-white hover:bg-emerald-700">Tutup</button>
                </form>
              <?php else: ?>
                <a class="rounded-lg bg-gray-100 px-3 py-1.5 text-gray-500" href="<?php echo e(route('ticket.show',$t->id)); ?>">
                  Lihat
                </a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6" class="py-6 px-4 text-center text-gray-500">Belum ada tiket yang kamu tangani.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <div class="mt-4"><?php echo e($tickets->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\helpdesk-app\resources\views/it/my.blade.php ENDPATH**/ ?>