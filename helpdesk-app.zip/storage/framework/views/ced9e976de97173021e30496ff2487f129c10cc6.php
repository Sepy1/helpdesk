
<?php $__env->startSection('title', 'Detail Tiket'); ?>

<?php $__env->startSection('content'); ?>
<div class="grid gap-6 lg:grid-cols-3">
  
  <div class="lg:col-span-2 space-y-6">

    
    <div class="bg-white rounded-2xl shadow-sm ring-1 ring-gray-100 p-6">
      <div class="flex items-start justify-between gap-4">
        <div>
          <h2 class="text-lg font-semibold text-gray-800">#<?php echo e($ticket->nomor_tiket); ?></h2>
          <p class="text-sm text-gray-500">
            Dibuat oleh: <span class="font-medium text-gray-700"><?php echo e($ticket->user->name ?? '-'); ?></span>
            • <?php echo e($ticket->created_at->format('d M Y H:i')); ?>

          </p>
        </div>

        <?php
          $badge = match($ticket->status) {
            'OPEN'        => 'bg-gray-100 text-gray-700 ring-gray-200',
            'ON_PROGRESS' => 'bg-amber-100 text-amber-800 ring-amber-200',
            'CLOSED'      => 'bg-emerald-100 text-emerald-800 ring-emerald-200',
          };
        ?>
        <span class="inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ring-1 <?php echo e($badge); ?>">
          <?php echo e($ticket->status); ?>

        </span>
      </div>

      <div class="mt-6 grid sm:grid-cols-2 gap-4">
        <div>
          <div class="text-xs text-gray-500 mb-1">Kategori</div>
          <div class="font-medium"><?php echo e($ticket->kategori); ?></div>
        </div>
        <div>
          <div class="text-xs text-gray-500 mb-1">IT Handler</div>
          <div class="font-medium"><?php echo e($ticket->it->name ?? '-'); ?></div>
        </div>
      </div>

      <div class="mt-6">
        <div class="text-xs text-gray-500 mb-1">Deskripsi</div>
        <div class="whitespace-pre-line text-gray-800"><?php echo e($ticket->deskripsi); ?></div>
      </div>

      <div class="mt-4">
        <div class="text-xs text-gray-500 mb-1">Lampiran</div>
        <?php if($ticket->lampiran): ?>
          <a class="text-indigo-600 hover:underline" href="<?php echo e(route('ticket.download', $ticket->id)); ?>">
            Unduh lampiran
          </a>
        <?php else: ?>
          <span class="text-gray-400">-</span>
        <?php endif; ?>
      </div>

      
      <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->role === 'IT'): ?>
          <div class="mt-6 flex flex-wrap gap-2">
            
            <?php if($ticket->status === 'OPEN'): ?>
              <form method="POST" action="<?php echo e(route('it.ticket.take', $ticket->id)); ?>">
                <?php echo csrf_field(); ?>
                <button class="rounded-lg bg-indigo-600 px-3 py-2 text-white hover:bg-indigo-700">
                  Ambil Alih
                </button>
              </form>
            <?php endif; ?>

            
            <?php if($ticket->status === 'ON_PROGRESS' && optional($ticket->it)->id === auth()->id()): ?>
              <form method="POST" action="<?php echo e(route('it.ticket.release', $ticket->id)); ?>">
                <?php echo csrf_field(); ?>
                <button class="rounded-lg bg-gray-200 px-3 py-2 text-gray-700 hover:bg-gray-300">
                  Lepas
                </button>
              </form>
              <form method="POST" action="<?php echo e(route('it.ticket.close', $ticket->id)); ?>">
                <?php echo csrf_field(); ?>
                <button class="rounded-lg bg-emerald-600 px-3 py-2 text-white hover:bg-emerald-700">
                  Tutup Tiket
                </button>
              </form>
            <?php endif; ?>

            
            <?php if($ticket->status === 'ON_PROGRESS' && optional($ticket->it)->id !== auth()->id()): ?>
              <button class="rounded-lg bg-gray-100 px-3 py-2 text-gray-500 cursor-not-allowed" disabled>
                Ditangani: <?php echo e($ticket->it->name ?? '-'); ?>

              </button>
            <?php endif; ?>

            
            <?php if($ticket->status === 'CLOSED'): ?>
              <form method="POST" action="<?php echo e(route('it.ticket.reopen', $ticket->id)); ?>">
                <?php echo csrf_field(); ?>
                <button class="rounded-lg bg-amber-600 px-3 py-2 text-white hover:bg-amber-700">
                  Reopen
                </button>
              </form>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      <?php endif; ?>
    </div>

    
    <div class="bg-white rounded-2xl shadow-sm ring-1 ring-gray-100 p-6">
      <h3 class="font-semibold text-gray-800 mb-3">Komentar / Progres</h3>

      
      <form method="POST" action="<?php echo e(route('ticket.comment', $ticket->id)); ?>" class="mb-4">
        <?php echo csrf_field(); ?>
        <textarea name="body" rows="3" required
                  class="w-full rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="Tulis update atau komentar..."></textarea>
        <div class="mt-2">
          <button class="rounded-lg bg-gray-900 px-3 py-2 text-white hover:bg-gray-800">Kirim</button>
        </div>
      </form>

      
      <div class="space-y-4">
        <?php $__empty_1 = true; $__currentLoopData = $ticket->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="rounded-lg border border-gray-100 p-3">
            <div class="flex items-center justify-between">
              <div>
                <div class="text-sm font-medium text-gray-800"><?php echo e($c->user->name ?? 'User'); ?></div>
                <div class="text-xs text-gray-500"><?php echo e($c->created_at->format('d M Y H:i')); ?></div>
              </div>
              <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->id() === $c->user_id || auth()->user()->role === 'IT'): ?>
                  <form method="POST" action="<?php echo e(route('comment.delete', $c->id)); ?>"
                        onsubmit="return confirm('Hapus komentar ini?')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="text-xs text-red-600 hover:underline">Hapus</button>
                  </form>
                <?php endif; ?>
              <?php endif; ?>
            </div>
            <div class="mt-2 text-gray-700 whitespace-pre-line"><?php echo e($c->body); ?></div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <div class="text-gray-500 text-sm">Belum ada komentar.</div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  
  <aside class="space-y-4">
    <div class="bg-white rounded-2xl shadow-sm ring-1 ring-gray-100 p-5">
      <h4 class="font-medium text-gray-800 mb-3">Ringkasan</h4>
      <dl class="text-sm text-gray-700 space-y-2">
        <div class="flex justify-between"><dt>Nomor</dt><dd class="font-medium"><?php echo e($ticket->nomor_tiket); ?></dd></div>
        <div class="flex justify-between"><dt>Status</dt><dd class="font-medium"><?php echo e($ticket->status); ?></dd></div>
        <div class="flex justify-between"><dt>Kategori</dt><dd><?php echo e($ticket->kategori); ?></dd></div>
        <div class="flex justify-between"><dt>Dibuat</dt><dd><?php echo e($ticket->created_at->format('d M Y H:i')); ?></dd></div>
        <div class="flex justify-between"><dt>Handler</dt><dd><?php echo e($ticket->it->name ?? '-'); ?></dd></div>
      </dl>

      <div class="mt-4">
        <a href="<?php echo e(url()->previous()); ?>"
           class="inline-flex items-center rounded-lg bg-gray-100 px-3 py-2 text-gray-700 hover:bg-gray-200">
          ← Kembali
        </a>
      </div>
    </div>
  </aside>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\helpdesk-app\resources\views/tickets/show.blade.php ENDPATH**/ ?>